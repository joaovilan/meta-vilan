#!/bin/sh
### BEGIN INIT INFO
# Provides:             starter
# Required-Start:
# Required-Stop:
# Default-Start:        S
# Default-Stop:
### END INIT INF

/usr/bin/starter &
